<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/forgot-password.css')); ?>">
</head>
<body>
    <section>
        <div class="wrapper">
            <div class="ellipse_4"></div>
            <div class="ellipse_5"></div>
            <div class="heart"></div>
        </div>
        <div class="img-box">
            <h2>Join Us</h2>
            <h3>Let’s make your dream in reality</h3>
        </div>
        <div class="form-box">
            <div class="form-value">
                <form method="POST" action="<?php echo e(route('password.request')); ?>">
                    <?php echo csrf_field(); ?>
                    <h2>Reset password</h2>
                    <?php if(session('status')): ?>
                        <div class="mb-4 font-medium text-sm text-green-600">
                            <h5><?php echo e(session('status')); ?></h5>
                        </div>
                    <?php endif; ?>
                    <div class="inputbox">
                        <input type="email" name="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email address">
                        <label for="">Email</label>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback is-invalid" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="button">
                        <input name="reset" id="reset" class="btn btn-block login-btn mb-4" type="submit" value="Reset">
                    </div>
                    
                    <div class="register">
                        <p>Don't have an account? <a href="<?php echo e(route('register')); ?>">Create Account</a></p>
                    </div>
                </form>
<?php /**PATH C:\Users\Виолетта\Desktop\Виолетта\pet\Registration fortify\laravel\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>